# python program for quickly doing calculations for astrophysics
# last modified: 9/13/21
# will continue to update

import math
# https://docs.python.org/3/library/math.html

# sources:
# An Introduction to Astrophysics and Cosmology - Andrew Norton
# Introduction to Stellar Structure - Walter J. Maciel 
# https://en.wikipedia.org/wiki/Apparent_magnitude
# https://astronomy.swin.edu.au/cosmos/a/Absolute+Magnitude

#constants:
c = 2.998*pow(10,8)
stef_boltz = 5.67*pow(10,-8)

#function for calculating transverse velocity
#d = distance in km
#mu = 
def calculateTranVelo(d, mu):
  print(d*(math.tan(mu)))

#function for calculating radial velocity; doppler shift formula
def calculateRadVelo(lambda_shift, lambda_wav):
  print(c*(lambda_shift/lambda_wav)) 

#function for calculating flux
def calculateFlux(radius, luminosity):
  print((luminosity/(4*math.pi*radius*radius))) 

#function for calculating escaping flux
def calculateFluxEscaping(temperature):
  print((stef_boltz*math.pow(temperature, 4))) 

#function for calculating luminosity
def calculateLuminosity(radius, temp):
  print(4*(math.pi)*pow(radius,2)*stef_boltz*pow(temp,4)) 

#function for calculating efficient temperature
def calculateEffTemp(radius, luminosity):
  print(pow((luminosity/(4*math.pi*stef_boltz*pow(radius,2)), 0.25))) 

#function for calculating apparant magnitude
def calculateApparantMagnitude(observed_flux_density, reference_flux):
  print(-2.5*math.log10(observed_flux_density/reference_flux))
  
#function for calculating absolute magnitude
def calculateAbsoluteMagnitude(observed_flux_density, reference_flux, distance):
  m = -2.5*math.log10(observed_flux_density/reference_flux)
  print(m-5*math.log(distance/10))




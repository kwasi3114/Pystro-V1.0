#name: pystro
#version: 1.0
#description: python library for performing calculations on stellar bodies in astrophysics
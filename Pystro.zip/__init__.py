from main import calculateTranVelo
from main import calculateRadVelo
from main import calculateLuminosity
from main import calculateEffTemp
from main import calculateFlux
from main import calculateFluxEscaping
from main import calculateApparantMagnitude
from main import calculateAbsoluteMagnitude
